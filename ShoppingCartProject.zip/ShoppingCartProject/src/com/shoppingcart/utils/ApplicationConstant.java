package com.shoppingcart.utils;

public class ApplicationConstant {

	public static final String INDEX_PAGE = "main.jsp";
	public static final String LOGIN_PAGE = "pages/login.jsp";
	public static final String HOME_PAGE = "pages/home.jsp";
	public static final String REGISTER_PAGE = "pages/register.jsp";
	public static final String PARTIAL_PAGE = "partialPage";
	public static final String SAVED_SUCCESSFULLY = " saved successfully";
	public static final String USER = "User";
	public static final String PRODUCT_PAGE = "admin/product.jsp";
	public static final String PRODUCT_LIST_PAGE = "admin/productList.jsp";
	public static final String PRODUCT = "Product";
	
	
}
