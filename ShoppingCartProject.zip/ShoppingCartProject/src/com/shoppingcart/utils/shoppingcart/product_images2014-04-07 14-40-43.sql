Select id, productid, imageUrl, isPrimary from shoppingcart.product_images
USE shoppingcart;

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL DEFAULT '0',
  `productid` int(11) DEFAULT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `isPrimary` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_productId` (`productid`),
  CONSTRAINT `FK_productId` FOREIGN KEY (`productid`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


