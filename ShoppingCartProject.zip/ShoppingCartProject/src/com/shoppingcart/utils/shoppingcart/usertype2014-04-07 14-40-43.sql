Select id, usertype from shoppingcart.usertype
USE shoppingcart;

CREATE TABLE `usertype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usertype` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


INSERT INTO shoppingcart.usertype(id,usertype) VALUES (1,'Admin');
INSERT INTO shoppingcart.usertype(id,usertype) VALUES (2,'Saler');
INSERT INTO shoppingcart.usertype(id,usertype) VALUES (3,'Buyer');
INSERT INTO shoppingcart.usertype(id,usertype) VALUES (4,'Guest');
