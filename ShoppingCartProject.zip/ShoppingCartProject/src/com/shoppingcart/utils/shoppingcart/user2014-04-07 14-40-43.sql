Select id, password, firstname, lastname, dob, createdDate, usertypeid, email from shoppingcart.user
USE shoppingcart;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) DEFAULT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `createdDate` date DEFAULT NULL,
  `usertypeid` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;


INSERT INTO shoppingcart.user(id,password,firstname,lastname,dob,createdDate,usertypeid,email) VALUES (1,'vishal27','vishal','yadav','1982-05-27','2014-04-02',1,'vishaly@xpanxion.co.in');
INSERT INTO shoppingcart.user(id,password,firstname,lastname,dob,createdDate,usertypeid,email) VALUES (4,'test','Buyer1','Buyer1','1984-04-20','2014-04-03',3,'test@test.com');
