package com.shoppingcart.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shoppingcart.dao.UserDAO;
import com.shoppingcart.model.User;
import com.shoppingcart.model.UserType;
import com.shoppingcart.service.UserService;

@Service("userService")
@Transactional(propagation=Propagation.SUPPORTS, readOnly = false)
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDao;
	 
	public UserDAO getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDAO userDao) {
		this.userDao = userDao;
	}

	@Override
	public void createUser(User user) {
		userDao.createUser(user);
	}

	@Override
	public User getUser(Integer id) {
		return userDao.getUser(id);
	}

	@Override
	public User userLogin(User user) {
		return userDao.getUserLogin(user);
		
	}

	@Override
	public void updateUser(User user) {
		 userDao.updateUser(user);
		
	}

	@Override
	public List<UserType> getAllUserType() {
		 
		return userDao.getAllUserType();
	}
	
}
