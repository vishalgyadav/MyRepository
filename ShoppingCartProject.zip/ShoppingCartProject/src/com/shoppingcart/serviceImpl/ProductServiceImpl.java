package com.shoppingcart.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.shoppingcart.dao.ProductDAO;
import com.shoppingcart.model.Product;
import com.shoppingcart.service.ProductService;
@Service("productService")
@Transactional(propagation=Propagation.SUPPORTS, readOnly = false)
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDAO productDao;
	
	@Override
	public 	List<Product>  getAllProduct() {
		return productDao.getAllProduct();
		
	}

	@Override
	public void createProduct(Product product) {
		productDao.createProduct(product);
	}

	@Override
	public Product getProduct(Float id) {
		 
		return productDao.getProduct(id);
	}

	@Override
	public void updateProduct(Product product) {
		 productDao.updateProduct(product);
		
	}
	

}
