package com.shoppingcart.dao;

import java.util.List;

import com.shoppingcart.model.User;
import com.shoppingcart.model.UserType;

 
public interface UserDAO {

	public void createUser(User user);
	
	public User getUser(Integer id);

	public User getUserLogin(User user);

	public User updateUser(User user);

	public List<UserType> getAllUserType();
}
