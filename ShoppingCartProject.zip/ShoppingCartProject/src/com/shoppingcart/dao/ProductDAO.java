package com.shoppingcart.dao;

import java.util.List;

import com.shoppingcart.model.Product;

public interface ProductDAO {

	public void createProduct(Product product);
	
	public List<Product> getAllProduct();
}
