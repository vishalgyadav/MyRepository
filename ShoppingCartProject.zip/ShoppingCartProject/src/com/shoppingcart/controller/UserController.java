package com.shoppingcart.controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionAttributeStore;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shoppingcart.model.User;
import com.shoppingcart.model.UserType;
import com.shoppingcart.service.UserService;
import com.shoppingcart.utils.ApplicationConstant;

@Controller
@SessionAttributes("userObj")
public class UserController {

	@Autowired
	UserService userService;

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@RequestMapping(value="/login", method={RequestMethod.GET})
	public String index(Model model, HttpServletRequest request) {
		User loginUser = (User) request.getSession().getAttribute("userObj");

		String redirectPage =  ApplicationConstant.INDEX_PAGE;
		if(loginUser == null)
		{
			model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.LOGIN_PAGE);
			User user = new User();
			user.setId(0);
			String msg = (String) model.asMap().get("msg");
			model.addAttribute("msg", msg);
			model.addAttribute("user", user);
		}
		else
		{
			redirectPage = "redirect:/home";
		}


		return redirectPage;
	}

	@RequestMapping(value="/userLogin", method=RequestMethod.POST)
	public String login(@ModelAttribute User user, Model model,
			BindingResult result, RedirectAttributes redirectAttrs, HttpServletRequest request, HttpServletResponse response){
		String msg = "";
		String redirectPage = "redirect:/home";
		try {
			User loginUser = userService.userLogin(user);
			if(loginUser == null)
			{
				msg = "Invalid Email or Password";
				redirectPage = "redirect:/login";
			}
			else
			{
				request.getSession().setAttribute("userObj", loginUser);
			}
		} catch (Exception e) {
			msg = "Invalid Email or Password";
			redirectPage = "redirect:/login";
		}

		redirectAttrs.addFlashAttribute("msg", msg);
		//model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.LOGIN_PAGE);
		return redirectPage;
	}


	@RequestMapping(value="/register", method={RequestMethod.GET})
	public String register(Model model,HttpServletRequest request) {
		User loginUser = (User) request.getSession().getAttribute("userObj");
		model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.REGISTER_PAGE);	
		List<UserType> userTypeList = userService.getAllUserType();
		model.addAttribute("userTypeList", userTypeList);
		String msg = (String) model.asMap().get("msg");
		model.addAttribute("msg", msg);
		if(loginUser != null)
		{
			model.addAttribute("user", loginUser);
		}
		else
		{
			model.addAttribute("user", new User());
		}
		return ApplicationConstant.INDEX_PAGE;
	}

	@RequestMapping(value="/userRegister", method=RequestMethod.POST)
	public String userRegistration(@ModelAttribute User user, Model model,
			BindingResult result, RedirectAttributes redirectAttrs, HttpServletRequest request, HttpServletResponse response){
		model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.LOGIN_PAGE);
		String msg = "";
		String redirectPage = "redirect:/login";
		try {
			userService.createUser(user);
			msg = ApplicationConstant.USER + " " + user.getFirstname() + " " + user.getLastname() + ApplicationConstant.SAVED_SUCCESSFULLY;
		} catch (Exception e) {
			msg = "Error while creating user, please try again later"; 
			redirectPage = "redirect:/register";
		}
		redirectAttrs.addFlashAttribute("msg", msg);
		return redirectPage;

	}

	@RequestMapping(value="/update", method = RequestMethod.POST)
	public String updateUser(@ModelAttribute User user,Model model,
			BindingResult result, RedirectAttributes redirectAttrs, HttpServletRequest request, HttpServletResponse response){
		
		String msg = "";
		String redirectPage = "redirect:/home";
		try {
			userService.updateUser(user);
			model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.HOME_PAGE);
			msg = ApplicationConstant.USER + " " + user.getFirstname() + " " + user.getLastname() + ApplicationConstant.SAVED_SUCCESSFULLY;
		} catch (Exception e) {
			msg = "Error while updating user, please try again later";
			model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.REGISTER_PAGE);
			redirectPage = "redirect:/register";
		}
		redirectAttrs.addFlashAttribute("msg", msg);
		return redirectPage;
		
	}
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String home(Model model, HttpServletRequest request){
		User loginUser = (User) request.getSession().getAttribute("userObj");
		model.addAttribute("user", loginUser);
		model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.HOME_PAGE);	
		return ApplicationConstant.INDEX_PAGE;
	}

	@RequestMapping(value = "/logout", method=RequestMethod.GET)
	public String logOut(Model model , HttpServletRequest request, SessionStatus status){
		status.setComplete();
		return  "redirect:/login";
	}
}
