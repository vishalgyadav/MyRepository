package com.shoppingcart.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shoppingcart.model.Product;
import com.shoppingcart.model.User;
import com.shoppingcart.service.ProductService;
import com.shoppingcart.service.UserService;
import com.shoppingcart.utils.ApplicationConstant;

@Controller
@SessionAttributes(value="userObj")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping(value="/productList", method=RequestMethod.GET)
	public String productList(Model model, HttpServletRequest request){
		model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.PRODUCT_LIST_PAGE);
		User loginUser = (User) request.getSession().getAttribute("userObj");
		List<Product> productList = productService.getAllProduct();
		model.addAttribute("user", loginUser);
		model.addAttribute("productList", productList);
		return ApplicationConstant.INDEX_PAGE;
	}
	
	@RequestMapping(value="/addProduct", method=RequestMethod.GET)
	public String addProduct(Model model, HttpServletRequest request){
		model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.PRODUCT_PAGE);
		User loginUser = (User) request.getSession().getAttribute("userObj");
		model.addAttribute("user", loginUser);
		return ApplicationConstant.INDEX_PAGE;
	}
	
	@RequestMapping(value="/createProduct", method=RequestMethod.GET)
	public String addProduct(@ModelAttribute Product product, Model model,  
			BindingResult result, RedirectAttributes redirectAttrs, HttpServletRequest request, HttpServletResponse response){
		String msg = "";
		String redirectPage = "redirect:/productList";
		try {
			productService.createProduct(product);
			msg = ApplicationConstant.PRODUCT + " " + product.getName() + ApplicationConstant.SAVED_SUCCESSFULLY;
		} catch (Exception e) {
			msg = "Error while creating user, please try again later"; 
			redirectPage = "redirect:/addProduct";
		}
		redirectAttrs.addFlashAttribute("msg", msg);
		return redirectPage;
//		model.addAttribute(ApplicationConstant.PARTIAL_PAGE, ApplicationConstant.PRODUCT_PAGE);
//		User loginUser = (User) request.getSession().getAttribute("userObj");
//		model.addAttribute("user", loginUser);
	}
}
