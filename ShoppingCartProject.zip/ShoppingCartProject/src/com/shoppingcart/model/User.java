package com.shoppingcart.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

 

@Entity
@Table(name="user")
@XmlRootElement
@NamedNativeQueries({@NamedNativeQuery(
            name = "login",
            query = "SELECT * FROM user WHERE email = :email and password = :password",
            resultClass = User.class),
@NamedNativeQuery(
        name = "user",
        query = "SELECT * FROM user WHERE id = :id",
        resultClass = User.class),
@NamedNativeQuery(
        name = "createUser",
        query = "CALL createUser(:password, :firstname, :lastname, :dob, :created_date, :usertypeid, :email);",
        resultClass = User.class),
@NamedNativeQuery(
        name = "updateUser",
        query = "CALL updateUser(:id, :password, :firstname, :lastname, :dob, :created_date, :usertypeid, :email);",
        resultClass = User.class),
@NamedNativeQuery(
                name = "alluser",
                query = "SELECT * FROM user",
                resultClass = User.class)
})
public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7666225595602568987L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id = 0;
	 
	@Column(name="password")
	private String password;
	
	@Column(name="firstname")
	private String firstname;
	
	@Column(name="lastname")
	private String lastname;
	
	@Column(name="dob")
	private Date dob;
	
	@Column(name="createdDate")
	private Date createdDate;
	
	@Column(name="usertypeid")
	private int usertypeid;

	@Column(name="email")
	private String email;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getUsertypeid() {
		return usertypeid;
	}

	public void setUsertypeid(int usertypeid) {
		this.usertypeid = usertypeid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	  
}
