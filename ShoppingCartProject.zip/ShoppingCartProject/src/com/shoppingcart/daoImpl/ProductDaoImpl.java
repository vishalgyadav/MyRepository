package com.shoppingcart.daoImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.shoppingcart.dao.ProductDAO;
import com.shoppingcart.model.Product;
import com.shoppingcart.model.UserType;
@Repository("productDao")
@Service("productDao")
@Transactional
public class ProductDaoImpl implements ProductDAO {

	@Resource(name = "sessionFactory")
	SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public void createProduct(Product product) {
		//query="CALL createProduct(:name, :description, :createdDt, :instock)", resultClass=Product.class),
		Session session = sessionFactory.getCurrentSession();
		session.getNamedQuery("createProduct")
		.setString("name", product.getName())
		.setString("description", product.getDescription())
		.setDate("createdDt", new Date())
		.setFloat("price", product.getPrice()).executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> getAllProduct() {
		List<Product> productList = new ArrayList<Product>();
		 Session session = sessionFactory.getCurrentSession();
		 productList = session.getNamedQuery("allProduct").list();
		return productList;
	}
}
