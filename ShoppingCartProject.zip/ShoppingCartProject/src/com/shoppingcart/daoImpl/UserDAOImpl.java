package com.shoppingcart.daoImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
 





import com.shoppingcart.dao.UserDAO;
import com.shoppingcart.model.User;
import com.shoppingcart.model.UserType;
@Repository("userDao")
@Service("userDao")
@Transactional
public class UserDAOImpl implements UserDAO {

	@Resource(name = "sessionFactory")
	SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void createUser(User user) {
		//CALL createUser(:password, :firstname, :lastname, :dob, :created_date, :usertypeid, :email);
		Session session = sessionFactory.getCurrentSession();
		session.getNamedQuery("createUser")
		.setString("password", user.getPassword())
		.setString("firstname", user.getFirstname())
		.setString("lastname", user.getLastname())
		.setDate("dob", user.getDob())
		.setDate("created_date", new Date())
		.setInteger("usertypeid", user.getUsertypeid())
		.setString("email", user.getEmail()).executeUpdate();
	}

	@Override
	public User getUser(Integer id) {
		Query query =sessionFactory.getCurrentSession().getNamedQuery("user").setInteger("id", id);
		User user = (User) query.uniqueResult();
		return user;
	}

	@Override
	public User getUserLogin(User user) {
		Query query =sessionFactory.getCurrentSession().getNamedQuery("login")
				.setString("email", user.getEmail())
				.setString("password", user.getPassword());
		User userObj = (User) query.uniqueResult();
		return userObj;
	}

	@Override
	public User updateUser(User user) {
		//CALL createUser(:password, :firstname, :lastname, :dob, :created_date, :usertypeid, :email);
				Session session = sessionFactory.getCurrentSession();
				session.getNamedQuery("updateUser")
				.setInteger("id", user.getId())
				.setString("password", user.getPassword())
				.setString("firstname", user.getFirstname())
				.setString("lastname", user.getLastname())
				.setDate("dob", user.getDob())
				.setDate("created_date", new Date())
				.setInteger("usertypeid", 1)
				.setString("email", user.getEmail()).executeUpdate();
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserType> getAllUserType() {
		 @SuppressWarnings("unused")
		List<UserType> userTypeList = new ArrayList<UserType>();
		 Session session = sessionFactory.getCurrentSession();
		 userTypeList = session.getNamedQuery("allusertype").list();
		return userTypeList;
	}


}
