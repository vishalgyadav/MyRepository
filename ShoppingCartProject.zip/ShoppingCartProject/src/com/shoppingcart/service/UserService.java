package com.shoppingcart.service;

import java.util.List;

import com.shoppingcart.model.User;
import com.shoppingcart.model.UserType;

public interface UserService {

	public void createUser(User user);

	public User getUser(Integer id);

	public User userLogin(User user);

	public void updateUser(User user);

	public List<UserType> getAllUserType();
}
