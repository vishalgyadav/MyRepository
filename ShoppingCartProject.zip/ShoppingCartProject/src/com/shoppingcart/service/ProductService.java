package com.shoppingcart.service;

import java.util.List;

import com.shoppingcart.model.Product;

public interface ProductService {

	public void createProduct(Product product);
	
	public 	List<Product>  getAllProduct(); 
}
